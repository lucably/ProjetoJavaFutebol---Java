/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexao.Persistencia;
import static dao.ComissaoDAO.auxDispose;
import gui.JFrmCadastroAdmin;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Admin;

/**
 *
 * @author lucas
 */
public class AdminDAO implements interfaceDAO.InterfaceDAO{
    static int auxDispose = 0;
    @Override
    public void adicionar(Object obj) {
        Admin admin = (Admin) obj;
        
        PreparedStatement ps2 = null;
        
        String senha = String.valueOf(admin.getsenha());
        auxDispose = 0;
        try {
            ps2 = Persistencia.conexao().prepareStatement("Insert into login (senha,usuario,tipo_usuario ) values (?,?,3)");
            ps2.setString(1, senha);
            ps2.setString(2, admin.getUsuario());
            ps2.executeUpdate();
            auxDispose ++;
        } catch (SQLException ex) {
            Logger.getLogger(JFrmCadastroAdmin.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    
    public static int pegaDispose(){
        return auxDispose;
    }

    @Override
    public void remover(Object obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void atualiza(Object obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<Object> consultar(Object obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
