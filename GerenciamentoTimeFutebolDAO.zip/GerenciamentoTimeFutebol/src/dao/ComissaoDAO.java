/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexao.Persistencia;
import static dao.TorcedorDAO.auxDispose;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.Comissao;
import model.Jogador;


/**
 *
 * @author lucas
 */
public class ComissaoDAO implements interfaceDAO.InterfaceDAO{

    static int auxDispose = 0;
    @Override
    public void adicionar(Object obj) {
        
        Comissao comissao = (Comissao) obj;
        
        PreparedStatement ps = null;
        PreparedStatement ps2 = null;
        int aux = 0;
        auxDispose = 0;

        try {
            ps = Persistencia.conexao().prepareStatement("Insert into comissao (contrato, cpf, dataFim, dataInicio, email, nome, nomeUsuario, posicao, salario, senha, sobrenome, telefone, tipo_usuario) values (?,?,?,?,?,?,?,?,?,?,?,?,1)");
            ps2 = Persistencia.conexao().prepareStatement("Insert into login (senha,usuario,tipo_usuario ) values (?,?,2)");
            
            if (comissao.getContrato().equals("") || comissao.getCpf().equals("") || comissao.getDataFim().equals("") || comissao.getPosicao().equals("") || comissao.getNomeUsuario().equals("") || comissao.getSenha().equals("") || comissao.getSenha2().equals("") || comissao.getEmail().equals("") || comissao.getNome().equals("") || comissao.getSalario() == 0 || comissao.getSobrenome().equals("") || comissao.getTelefone().equals("") || comissao.getDataInicio().equals("")) {
                JOptionPane.showMessageDialog(null, "Algum campo está VAZIO!", "Erro no Sistema", 1);
            } else {
                if (comissao.getEmail().contains("@")) {
                    ps.setDouble(1, comissao.getContrato());
                    ps.setString(2, comissao.getCpf());
                    ps.setString(3, comissao.getDataFim());
                    ps.setString(4, comissao.getDataInicio());
                    ps2.setString(2, comissao.getNomeUsuario());
                    ps.setString(5, comissao.getEmail());
                    ps2.setString(1, comissao.getSenha()); 
                    ps.setString(6, comissao.getNome());
                    ps.setString(7, comissao.getNomeUsuario());
                    ps.setObject(8, comissao.getPosicao());
                    ps.setDouble(9, comissao.getSalario());
                    ps.setString(10, comissao.getSenha());  
                    if (comissao.getSenha().equals(comissao.getSenha2())) {
                        ps.setString(11, comissao.getSobrenome());
                        ps.setString(12, comissao.getTelefone());
                        ps.executeUpdate();
                        ps2.executeUpdate();
                        auxDispose ++;
                    } else {
                        JOptionPane.showMessageDialog(null, "Senhas DIFERENTES!", "Erro no Sistema", 1);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Email Inválido!", "Erro no Sistema", 1);
                }
                if (auxDispose != 0) {
                    JOptionPane.showMessageDialog(null, "Comissão Cadastrado com Sucesso! ", "SISTEMA:", 2, null);
                }

            }
        } catch (SQLException e) {
            System.out.println("Erro ao executar comando SQL" + e);
        }
    }
    
    public static int pegaDispose(){
        return auxDispose;
    }

    @Override
    public void remover(Object obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void atualiza(Object obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<Object> consultar(Object obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
