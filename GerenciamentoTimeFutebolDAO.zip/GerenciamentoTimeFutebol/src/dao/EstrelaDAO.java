package dao;

import conexao.Persistencia;
import gui.JFrmCadastroAdmin;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.Estrela;

/**
 *
 * @author lucas
 */
public class EstrelaDAO implements interfaceDAO.InterfaceDAO{
    static int auxDispose = 0;
    @Override
    public void adicionar(Object obj) {
        Estrela estrela = (Estrela) obj;
        
        PreparedStatement ps2 = null;
        auxDispose = 0;
        try {
            ps2 = Persistencia.conexao().prepareStatement("Insert into estrela (anos, nome, qnt_titulos, gols ) values (?, ?, ?, ?)");
            ps2.setInt(1, estrela.getAnos());
            ps2.setString(2, estrela.getNome());
            ps2.setInt(3, estrela.getQnt_titulos());
            ps2.setInt(4, estrela.getGols());
            ps2.executeUpdate();
            auxDispose++;
            JOptionPane.showMessageDialog(null, "Estrela do Time Cadastrado com Sucesso! ", "SISTEMA:", 2, null);
            
        } catch (SQLException ex) {
            Logger.getLogger(JFrmCadastroAdmin.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public static int pegaDispose(){
        return auxDispose;
    }

    @Override
    public void remover(Object obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void atualiza(Object obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<Object> consultar(Object obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}