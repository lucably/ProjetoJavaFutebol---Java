/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexao.Persistencia;
import static dao.TorcedorDAO.auxDispose;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.Jogador;

/**
 *
 * @author lucas
 */
public class JogadorDAO implements interfaceDAO.InterfaceDAO{
    static int auxDispose = 0;
    @Override
    public void adicionar(Object obj) {
        
        Jogador jogador = (Jogador) obj;
        
        PreparedStatement ps = null;
        PreparedStatement ps2 = null;
        int aux = 0;
        auxDispose = 0;

        try {
            ps = Persistencia.conexao().prepareStatement("Insert into jogador (contrato, cpf, dataFim, dataInicio, email, nome, nomeUsuario, posicao, salario, senha, sobrenome, telefone, tipo_usuario,nascimento) values (?,?,?,?,?,?,?,?,?,?,?,?,1,?)");
            ps2 = Persistencia.conexao().prepareStatement("Insert into login (senha,usuario,tipo_usuario ) values (?,?,1)");
            
            if (jogador.getContrato().equals("") || jogador.getCpf().equals("") || jogador.getDataFim().equals("") || jogador.getPosicao().equals("") || jogador.getNomeUsuario().equals("") || jogador.getSenha().equals("") || jogador.getSenha2().equals("") || jogador.getEmail().equals("") || jogador.getNome().equals("") || jogador.getSalario() == 0 || jogador.getSobrenome().equals("") || jogador.getTelefone().equals("") || jogador.getDataInicio().equals("")) {
                JOptionPane.showMessageDialog(null, "Algum campo está VAZIO!", "Erro no Sistema", 1);
            } else {
                if (jogador.getEmail().contains("@")) {
                    ps.setDouble(1, jogador.getContrato());
                    ps.setString(2, jogador.getCpf());
                    ps.setString(3, jogador.getDataFim());
                    ps.setString(4, jogador.getDataInicio());
                    ps2.setString(2, jogador.getNomeUsuario());
                    ps.setString(5, jogador.getEmail());
                    ps2.setString(1, jogador.getSenha()); 
                    ps.setString(6, jogador.getNome());
                    ps.setString(7, jogador.getNomeUsuario());
                    ps.setObject(8, jogador.getPosicao());
                    ps.setDouble(9, jogador.getSalario());
                    ps.setString(10, jogador.getSenha());  
                    if (jogador.getSenha().equals(jogador.getSenha2())) {
                        ps.setString(11, jogador.getSobrenome());
                        ps.setString(12, jogador.getTelefone());
                        ps.setString(13, jogador.getNascimento());
                        ps.executeUpdate();
                        ps2.executeUpdate();
                        auxDispose ++;
                    } else {
                        JOptionPane.showMessageDialog(null, "Senhas DIFERENTES!", "Erro no Sistema", 1);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Email Inválido!", "Erro no Sistema", 1);
                }
                if (auxDispose != 0) {
                    JOptionPane.showMessageDialog(null, "Jogador Cadastrado com Sucesso! ", "SISTEMA:", 2, null);
                }

            }
        } catch (SQLException e) {
            System.out.println("Erro ao executar comando SQL" + e);
        }
    }
    
    public static int pegaDispose(){
        return auxDispose;
    }

    @Override
    public void remover(Object obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void atualiza(Object obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<Object> consultar(Object obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
