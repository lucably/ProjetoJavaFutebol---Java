/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexao.Persistencia;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.Torcedor;

/**
 *
 * @author lucas
 */
public class TorcedorDAO implements interfaceDAO.InterfaceDAO{ 
    
    static int auxDispose = 0;
    @Override
    public void adicionar(Object obj) {
        Torcedor torcedor = (Torcedor) obj;
        PreparedStatement ps = null;
        PreparedStatement ps2 = null;
        auxDispose = 0;
        

        try {
            ps = Persistencia.conexao().prepareStatement("Insert into torcedor (cpf,email,nome,nomeUsuario,senha,sobrenome,telefone,tipo_usuario) values (?,?,?,?,?,?,?,0)");
            ps2 = Persistencia.conexao().prepareStatement("Insert into login (senha,usuario,tipo_usuario ) values (?,?,0)");

            if (torcedor.getEmail().equals("") || torcedor.getCpf().equals("") || torcedor.getEmail().equals("") || torcedor.getNome().equals("") || torcedor.getNomeUsuario().equals("") || torcedor.getSobrenome().equals("") || torcedor.getTelefone().equals("") || torcedor.getSenha().equals("") || torcedor.getSenhaConf().equals("")) {
                JOptionPane.showMessageDialog(null, "Algum campo está VAZIO!", "Erro no Sistema", 1);
            } else {
                if (torcedor.getEmail().contains("@")) {
                    ps.setString(1, torcedor.getCpf()); 
                    ps.setString(2, torcedor.getEmail());
                    ps.setString(3, torcedor.getNome());
                    ps.setString(4, torcedor.getNomeUsuario());
                    ps2.setString(2, torcedor.getNomeUsuario());
                    ps.setString(5, torcedor.getSenha());
                    ps2.setString(1, torcedor.getSenha());
                    if (torcedor.getSenha().equals(torcedor.getSenhaConf())) {
                        ps.setString(6, torcedor.getSobrenome());
                        ps.setString(7, torcedor.getTelefone());
                        ps.executeUpdate();
                        ps2.executeUpdate();
                        auxDispose++;
                    } else {
                        JOptionPane.showMessageDialog(null, "Senhas DIFERENTES!", "Erro no Sistema", 1);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Email Inválido!", "Erro no Sistema", 1);
                }
                if (auxDispose != 0) {
                    JOptionPane.showMessageDialog(null, "Cadastrado com Sucesso! ", "SISTEMA:", 2, null);  
                }

            }
        } catch (SQLException e) {
            System.out.println("Erro ao executar comando SQL" + e);
        }
    }                                                 
    
    public static int pegaDispose(){
        return auxDispose;
    }

    @Override
    public void remover(Object obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void atualiza(Object obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<Object> consultar(Object obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
