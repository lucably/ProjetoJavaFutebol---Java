package gerenciamento_de_time_futebol;

import gui.JFrmTelaLogin;

public class Gerenciamento_De_Time_Futebol {

    public static void main(String[] args) {
        JFrmTelaLogin telaLogin = new JFrmTelaLogin();
        telaLogin.setVisible(true);
              
    }
}