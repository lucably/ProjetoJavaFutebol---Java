/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import conexao.Persistencia;
import static gui.JFrmElencoCompleto.naoDeixaRepetirTexto2;
import java.awt.Color;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author lucas
 */
public class JFrmDeleteAdmin extends javax.swing.JFrame {

    static int naoRepete = 0;
    int mostraMensagem = 0;

    public JFrmDeleteAdmin() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnExclusao = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        campoExcluirJogador = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        mostraTudo = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        jLabel1.setText("EXCLUIR ADMIN");

        jLabel2.setText("Nome do Usuario do ADMIN:");

        btnExclusao.setText("DELETAR");
        btnExclusao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExclusaoActionPerformed(evt);
            }
        });

        jButton2.setText("VOLTAR");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        campoExcluirJogador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoExcluirJogadorActionPerformed(evt);
            }
        });

        mostraTudo.setEditable(false);
        mostraTudo.setColumns(20);
        mostraTudo.setRows(5);
        jScrollPane1.setViewportView(mostraTudo);

        jButton1.setText("Visualizar Admin");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(btnExclusao))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(campoExcluirJogador, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(103, 103, 103)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(campoExcluirJogador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnExclusao)
                    .addComponent(jButton2))
                .addGap(37, 37, 37)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 294, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnExclusaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExclusaoActionPerformed

        PreparedStatement ps2 = null;
        ResultSet rs2 = null;

        try {

            ps2 = Persistencia.conexao().prepareStatement("Select * from login");
            rs2 = ps2.executeQuery();

            while (rs2.next()) {
                if (rs2.getString("usuario").equals(campoExcluirJogador.getText())) {

                    ps2 = Persistencia.conexao().prepareStatement("Delete from login Where usuario = ? and tipo_usuario = 3");
                    ps2.setString(1, campoExcluirJogador.getText());
                    ps2.executeUpdate();
                    mostraMensagem = 1;
                    mostraTudo.setText("");
                    naoRepete = 0;
                }
            }

            if (mostraMensagem == 0) {
                JOptionPane.showMessageDialog(this, "Usuario não Existe!", "SISTEMA:", 0, null);
            }

            if (mostraMensagem == 1) {
                JOptionPane.showMessageDialog(this, "Administrador Deletado com Sucesso!", "SISTEMA:", 2, null);
                dispose();
                campoExcluirJogador.setText("");
                mostraMensagem = 0;
            }

        } catch (SQLException e) {
            System.out.println("Erro ao executar o comando SQL" + e);
        }
    }//GEN-LAST:event_btnExclusaoActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        dispose();
        campoExcluirJogador.setText("");
        naoRepete = 0;
        mostraTudo.setText("");
    }//GEN-LAST:event_jButton2ActionPerformed

    private void campoExcluirJogadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoExcluirJogadorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoExcluirJogadorActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        PreparedStatement ps = null;

        ResultSet rs = null;

        if (naoRepete == 0) {
            try {
                ps = Persistencia.conexao().prepareStatement("Select * from login");
                rs = ps.executeQuery();

                while (rs.next()) {
                    if (rs.getInt("tipo_usuario") == 3) {
                        mostraTudo.append("Nome do USUARIO: " + rs.getString("usuario") + "\n\n");
                    }
                }

            } catch (SQLException e) {
                System.out.println("Erro ao executar o comando SQL" + e);
            }
        }
        naoRepete++;
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnExclusao;
    private javax.swing.JTextField campoExcluirJogador;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea mostraTudo;
    // End of variables declaration//GEN-END:variables
}
