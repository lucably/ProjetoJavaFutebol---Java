/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import conexao.Persistencia;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author lucas
 */
public class JFrmPerfilJogador extends javax.swing.JFrame {

    /**
     * Creates new form JFrmPerfilTorcedor
     */
    public JFrmPerfilJogador() {
        initComponents();
        this.setLocationRelativeTo(null);
        caixaCombinacaoJogador.setEnabled(false);
        PreparedStatement ps = null;
        PreparedStatement ps2 = null;
        String auxUsuario = JFrmTelaLogin.pegaTelaCadastroJogador();
        ResultSet rs = null;
        ResultSet rs2 = null;
        try {
            ps = Persistencia.conexao().prepareStatement("Select * from jogador");
            rs = ps.executeQuery();
           
            while (rs.next()) {
                if (rs.getString("nomeUsuario").equals(auxUsuario)) {
                    campoNomeJogador.setText(rs.getString("nome"));
                    campoCpfJogador.setText(rs.getString("cpf"));
                    campoEmailJogador.setText(rs.getString("email"));
                    campoSobrenomeJogador.setText(rs.getString("sobrenome"));
                    campoSenhaJogador.setText(rs.getString("senha"));
                    campoTelefoneJogador.setText(rs.getString("telefone"));
                    campoDataInicioJogador.setText(rs.getString("dataInicio"));
                    campoDataFImJogador.setText(rs.getString("dataFim"));
                    caixaCombinacaoJogador.setSelectedItem(rs.getString("posicao"));
                }
            }

        } catch (SQLException e) {
            System.out.println("Erro ao executar o comando SQL" + e);
        }
        
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        btnVoltarTorcedor = new javax.swing.JButton();
        campoNomeJogador = new javax.swing.JTextField();
        campoCpfJogador = new javax.swing.JTextField();
        campoSenhaJogador = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        campoTelefoneJogador = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        campoSobrenomeJogador = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        campoEmailJogador = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        btnSalvarTorcedor = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        btnEditar = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        campoDataInicioJogador = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        campoDataFImJogador = new javax.swing.JTextField();
        caixaCombinacaoJogador = new javax.swing.JComboBox();
        jLabel14 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Dialog", 3, 36)); // NOI18N
        jLabel1.setText("PERFIL");

        btnVoltarTorcedor.setText("VOLTAR");
        btnVoltarTorcedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarTorcedorActionPerformed(evt);
            }
        });

        campoNomeJogador.setEditable(false);
        campoNomeJogador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoNomeJogadorActionPerformed(evt);
            }
        });

        campoCpfJogador.setEditable(false);

        campoSenhaJogador.setEditable(false);

        jLabel2.setText("NOME:");

        campoTelefoneJogador.setEditable(false);

        jLabel3.setText("SOBRENOME:");

        campoSobrenomeJogador.setEditable(false);

        jLabel4.setText("CPF:");

        campoEmailJogador.setEditable(false);

        jLabel5.setText("EMAIL:");

        jLabel6.setText("SENHA:");

        btnSalvarTorcedor.setText("SALVAR");
        btnSalvarTorcedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarTorcedorActionPerformed(evt);
            }
        });

        jLabel8.setText("TELEFONE:");

        btnEditar.setText("EDITAR");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        jLabel12.setText("DATA INICIO:");

        campoDataInicioJogador.setEditable(false);

        jLabel13.setText("DATA FIM:");

        campoDataFImJogador.setEditable(false);

        caixaCombinacaoJogador.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "ATACANTE", "ZAGUEIRO", "LATERAL ESQUERDO", "LATERA DIREITO", "VOLANTE", "MEIA", "GOLEIRO" }));

        jLabel14.setText("POSIÇÃO:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(15, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel2)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(campoCpfJogador, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(campoNomeJogador, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(campoSenhaJogador, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(55, 55, 55)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel5)
                            .addComponent(jLabel3)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel12)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(campoDataInicioJogador, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel13))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(56, 56, 56)
                                .addComponent(btnSalvarTorcedor)))
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnVoltarTorcedor)
                            .addComponent(campoDataFImJogador)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(campoSobrenomeJogador)
                                .addComponent(campoEmailJogador)
                                .addComponent(campoTelefoneJogador, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(caixaCombinacaoJogador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(209, 209, 209)
                        .addComponent(btnEditar)))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(167, 167, 167)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(campoSobrenomeJogador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(campoNomeJogador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(campoCpfJogador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(campoEmailJogador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(campoSenhaJogador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(campoTelefoneJogador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(campoDataInicioJogador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13)
                    .addComponent(campoDataFImJogador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(caixaCombinacaoJogador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addComponent(btnEditar)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSalvarTorcedor)
                    .addComponent(btnVoltarTorcedor))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void campoNomeJogadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoNomeJogadorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoNomeJogadorActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        campoCpfJogador.setEditable(true);
        campoEmailJogador.setEditable(true);
        campoNomeJogador.setEditable(true);
        campoSenhaJogador.setEditable(true);
        campoSobrenomeJogador.setEditable(true);
        campoTelefoneJogador.setEditable(true);
        campoDataInicioJogador.setEditable(true);
        campoDataFImJogador.setEditable(true);
        caixaCombinacaoJogador.setEnabled(true);
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnVoltarTorcedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarTorcedorActionPerformed
        dispose();
        campoCpfJogador.setEditable(false);
        campoEmailJogador.setEditable(false);
        campoNomeJogador.setEditable(false);
        campoSenhaJogador.setEditable(false);
        campoSobrenomeJogador.setEditable(false);
        campoTelefoneJogador.setEditable(false);
        campoDataInicioJogador.setEditable(false);
        campoDataFImJogador.setEditable(false);
        caixaCombinacaoJogador.setEnabled(false);
        
        PreparedStatement ps = null;
        ResultSet rs = null;
        String auxUsuario = JFrmTelaLogin.pegaTelaCadastroJogador();
          
        try {
            ps = Persistencia.conexao().prepareStatement("Select * from jogador");
            rs = ps.executeQuery();
           
            while (rs.next()) {
                if (rs.getString("nomeUsuario").equals(auxUsuario)) {
                    campoNomeJogador.setText(rs.getString("nome"));
                    campoCpfJogador.setText(rs.getString("cpf"));
                    campoEmailJogador.setText(rs.getString("email"));
                    campoSobrenomeJogador.setText(rs.getString("sobrenome"));
                    campoSenhaJogador.setText(rs.getString("senha"));
                    campoTelefoneJogador.setText(rs.getString("telefone"));
                    campoDataInicioJogador.setText(rs.getString("dataInicio"));
                    campoDataFImJogador.setText(rs.getString("dataFim"));
                    caixaCombinacaoJogador.setSelectedItem(rs.getString("posicao"));
                }
            }

        } catch (SQLException e) {
            System.out.println("Erro ao executar o comando SQL" + e);
        }
    }//GEN-LAST:event_btnVoltarTorcedorActionPerformed

    private void btnSalvarTorcedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarTorcedorActionPerformed
        PreparedStatement ps = null;
        PreparedStatement ps2 = null;
        PreparedStatement ps3 = null;
        PreparedStatement ps4 = null;
        ResultSet rs = null;
        ResultSet rs2 = null;
        String auxUsuario = JFrmTelaLogin.pegaTelaCadastroJogador();
        try {
            ps = Persistencia.conexao().prepareStatement("Select * from jogador");
            ps2 = Persistencia.conexao().prepareStatement("Select * from login");
            rs = ps.executeQuery();
            rs2 = ps2.executeQuery();
            while (rs.next()) {
                if (rs.getString("nomeUsuario").equals(auxUsuario)) {
                    
                    ps3 = Persistencia.conexao().prepareStatement("Update jogador set cpf = ?,email = ?,nome = ?,senha = ?,sobrenome = ?,telefone = ?,dataInicio = ?,dataFim = ?,posicao = ? Where  nomeUsuario = ?" );
                    ps3.setString(1, campoCpfJogador.getText());
                    ps3.setString(2, campoEmailJogador.getText());
                    ps3.setString(3, campoNomeJogador.getText());
                    ps3.setString(4, campoSenhaJogador.getText());
                    ps3.setString(5, campoSobrenomeJogador.getText());
                    ps3.setString(6, campoTelefoneJogador.getText());
                    ps3.setString(7, campoDataInicioJogador.getText());
                    ps3.setString(8, campoDataFImJogador.getText());
                    ps3.setObject(9, caixaCombinacaoJogador.getSelectedItem());
                    ps3.setString(10, auxUsuario);
                    ps3.executeUpdate();
                    JOptionPane.showMessageDialog(this, auxUsuario+" foi Editado com Sucesso!", "SISTEMA", 2, null);
                }
                
            }
            while (rs2.next()) {
                
                if (rs2.getString("usuario").equals(auxUsuario)) {
                    ps4 = Persistencia.conexao().prepareStatement("Update login set senha = ? Where usuario = ?" );
                    ps4.setString(1, campoSenhaJogador.getText());
                    ps4.setString(2, auxUsuario);
                    ps4.executeUpdate();
                }
            }
            dispose();

        } catch (SQLException e) {
            System.out.println("Erro ao executar o comando SQL" + e);
        }
        
        campoCpfJogador.setEditable(false);
        campoEmailJogador.setEditable(false);
        campoNomeJogador.setEditable(false);
        campoSenhaJogador.setEditable(false);
        campoSobrenomeJogador.setEditable(false);
        campoTelefoneJogador.setEditable(false);
        campoDataInicioJogador.setEditable(false);
        campoDataFImJogador.setEditable(false);
        caixaCombinacaoJogador.setEnabled(false);
        
    }//GEN-LAST:event_btnSalvarTorcedorActionPerformed

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnSalvarTorcedor;
    private javax.swing.JButton btnVoltarTorcedor;
    private javax.swing.JComboBox caixaCombinacaoJogador;
    private javax.swing.JTextField campoCpfJogador;
    private javax.swing.JTextField campoDataFImJogador;
    private javax.swing.JTextField campoDataInicioJogador;
    private javax.swing.JTextField campoEmailJogador;
    private javax.swing.JTextField campoNomeJogador;
    private javax.swing.JTextField campoSenhaJogador;
    private javax.swing.JTextField campoSobrenomeJogador;
    private javax.swing.JTextField campoTelefoneJogador;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    // End of variables declaration//GEN-END:variables
}
