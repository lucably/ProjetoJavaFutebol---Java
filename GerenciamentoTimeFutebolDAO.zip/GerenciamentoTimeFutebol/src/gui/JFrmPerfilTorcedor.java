/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import conexao.Persistencia;
import static gui.JFrmElencoCompleto.naoDeixaRepetirTexto;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author lucas
 */
public class JFrmPerfilTorcedor extends javax.swing.JFrame {

    public JFrmPerfilTorcedor() {
        initComponents();
        this.setLocationRelativeTo(null);
        PreparedStatement ps = null;
        PreparedStatement ps2 = null;
        String auxUsuario = JFrmTelaLogin.pegaTelaCadastroJogador();
        ResultSet rs = null;
        ResultSet rs2 = null;
        try {
            ps = Persistencia.conexao().prepareStatement("Select * from torcedor");
            rs = ps.executeQuery();
            ps2 = Persistencia.conexao().prepareStatement("Select * from doacao");
            rs2 = ps2.executeQuery();
            while (rs.next()) {
                if (rs.getString("nomeUsuario").equals(auxUsuario)) {
                    campoNomeTorcedor.setText(rs.getString("nome"));
                    campoCpfTorcedor.setText(rs.getString("cpf"));
                    campoEmailTorcedor.setText(rs.getString("email"));
                    campoSobrenomeTorcedor.setText(rs.getString("sobrenome"));
                    campoSenhaTorcedor.setText(rs.getString("senha"));
                    campoTelefoneTorcedor.setText(rs.getString("telefone"));
                }
            }
            while(rs2.next()) {
                if(rs2.getString("nomeUsuario").equals(auxUsuario)) {
                    campoDoacaoMensal.setText(rs2.getString("opcao_pag"));
                }
            }

        } catch (SQLException e) {
            System.out.println("Erro ao executar o comando SQL" + e);
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        btnVoltarTorcedor = new javax.swing.JButton();
        campoNomeTorcedor = new javax.swing.JTextField();
        campoCpfTorcedor = new javax.swing.JTextField();
        campoSenhaTorcedor = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        campoTelefoneTorcedor = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        campoSobrenomeTorcedor = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        campoEmailTorcedor = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        btnSalvarTorcedor = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        btnEditar = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        campoDoacaoMensal = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Dialog", 3, 36)); // NOI18N
        jLabel1.setText("PERFIL");

        btnVoltarTorcedor.setText("VOLTAR");
        btnVoltarTorcedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarTorcedorActionPerformed(evt);
            }
        });

        campoNomeTorcedor.setEditable(false);
        campoNomeTorcedor.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                campoNomeTorcedorFocusGained(evt);
            }
        });
        campoNomeTorcedor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                campoNomeTorcedorMouseEntered(evt);
            }
        });
        campoNomeTorcedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoNomeTorcedorActionPerformed(evt);
            }
        });

        campoCpfTorcedor.setEditable(false);

        campoSenhaTorcedor.setEditable(false);

        jLabel2.setText("NOME:");

        campoTelefoneTorcedor.setEditable(false);

        jLabel3.setText("SOBRENOME:");

        campoSobrenomeTorcedor.setEditable(false);

        jLabel4.setText("CPF:");

        campoEmailTorcedor.setEditable(false);

        jLabel5.setText("EMAIL:");

        jLabel6.setText("SENHA:");

        btnSalvarTorcedor.setText("SALVAR");
        btnSalvarTorcedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarTorcedorActionPerformed(evt);
            }
        });

        jLabel8.setText("TELEFONE:");

        btnEditar.setText("EDITAR");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        jLabel7.setText("Doação mensal: ");

        campoDoacaoMensal.setEditable(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(168, 168, 168)
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel4))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(campoCpfTorcedor, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(campoNomeTorcedor, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(campoSenhaTorcedor, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(55, 55, 55)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel8))
                                .addGap(4, 4, 4)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(campoSobrenomeTorcedor, javax.swing.GroupLayout.DEFAULT_SIZE, 164, Short.MAX_VALUE)
                            .addComponent(campoEmailTorcedor, javax.swing.GroupLayout.DEFAULT_SIZE, 164, Short.MAX_VALUE)
                            .addComponent(campoTelefoneTorcedor)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel7)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnSalvarTorcedor)
                                .addGap(109, 109, 109)
                                .addComponent(btnEditar)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 95, Short.MAX_VALUE)
                                .addComponent(btnVoltarTorcedor)
                                .addGap(30, 30, 30))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(campoDoacaoMensal, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap())))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(campoSobrenomeTorcedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(campoNomeTorcedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(campoCpfTorcedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(campoEmailTorcedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(campoSenhaTorcedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(campoTelefoneTorcedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel6))
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(campoDoacaoMensal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSalvarTorcedor)
                    .addComponent(btnEditar)
                    .addComponent(btnVoltarTorcedor)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void campoNomeTorcedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoNomeTorcedorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoNomeTorcedorActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        campoCpfTorcedor.setEditable(true);
        campoEmailTorcedor.setEditable(true);
        campoNomeTorcedor.setEditable(true);
        campoSenhaTorcedor.setEditable(true);
        campoSobrenomeTorcedor.setEditable(true);
        campoTelefoneTorcedor.setEditable(true);
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnVoltarTorcedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarTorcedorActionPerformed
        dispose();
        campoCpfTorcedor.setEditable(false);
        campoEmailTorcedor.setEditable(false);
        campoNomeTorcedor.setEditable(false);
        campoSenhaTorcedor.setEditable(false);
        campoSobrenomeTorcedor.setEditable(false);
        campoTelefoneTorcedor.setEditable(false);
        
        PreparedStatement ps = null;
        PreparedStatement ps2 = null;
        String auxUsuario = JFrmTelaLogin.pegaTelaCadastroJogador();
        ResultSet rs = null;
        ResultSet rs2 = null;
        try {
            ps = Persistencia.conexao().prepareStatement("Select * from torcedor");
            rs = ps.executeQuery();
            ps2 = Persistencia.conexao().prepareStatement("Select * from doacao");
            rs2 = ps2.executeQuery();
            while (rs.next()) {
                if (rs.getString("nomeUsuario").equals(auxUsuario)) {
                    campoNomeTorcedor.setText(rs.getString("nome"));
                    campoCpfTorcedor.setText(rs.getString("cpf"));
                    campoEmailTorcedor.setText(rs.getString("email"));
                    campoSobrenomeTorcedor.setText(rs.getString("sobrenome"));
                    campoSenhaTorcedor.setText(rs.getString("senha"));
                    campoTelefoneTorcedor.setText(rs.getString("telefone"));
                }
            }
            while(rs2.next()) {
                if(rs2.getString("nomeUsuario").equals(auxUsuario)) {
                    campoDoacaoMensal.setText(rs2.getString("opcao_pag"));
                }
            }

        } catch (SQLException e) {
            System.out.println("Erro ao executar o comando SQL" + e);
        }

    }//GEN-LAST:event_btnVoltarTorcedorActionPerformed

    private void campoNomeTorcedorFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_campoNomeTorcedorFocusGained

    }//GEN-LAST:event_campoNomeTorcedorFocusGained

    private void campoNomeTorcedorMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_campoNomeTorcedorMouseEntered

    }//GEN-LAST:event_campoNomeTorcedorMouseEntered

    private void btnSalvarTorcedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarTorcedorActionPerformed
        PreparedStatement ps = null;
        PreparedStatement ps2 = null;
        PreparedStatement ps3 = null;
        PreparedStatement ps4 = null;
        ResultSet rs = null;
        ResultSet rs2 = null;
        String auxUsuario = JFrmTelaLogin.pegaTelaCadastroJogador();
        try {
            ps = Persistencia.conexao().prepareStatement("Select * from torcedor");
            ps2 = Persistencia.conexao().prepareStatement("Select * from login");
            rs = ps.executeQuery();
            rs2 = ps2.executeQuery();
            while (rs.next()) {
                if (rs.getString("nomeUsuario").equals(auxUsuario)) {
                    
                    ps3 = Persistencia.conexao().prepareStatement("Update torcedor set cpf = ?,email = ?,nome = ?,senha = ?,sobrenome = ?,telefone = ? Where  nomeUsuario = ?" );
                    ps3.setString(1, campoCpfTorcedor.getText());
                    ps3.setString(2, campoEmailTorcedor.getText());
                    ps3.setString(3, campoNomeTorcedor.getText());
                    ps3.setString(4, campoSenhaTorcedor.getText());
                    ps3.setString(5, campoSobrenomeTorcedor.getText());
                    ps3.setString(6, campoTelefoneTorcedor.getText());
                    ps3.setString(7, auxUsuario);
                    ps3.executeUpdate();
                    JOptionPane.showMessageDialog(this, auxUsuario+" foi Editado com Sucesso!", "SISTEMA", 2, null);
                }
                
            }
            while (rs2.next()) {
                
                if (rs2.getString("usuario").equals(auxUsuario)) {
                    ps4 = Persistencia.conexao().prepareStatement("Update login set senha = ? Where usuario = ?" );
                    ps4.setString(1, campoSenhaTorcedor.getText());
                    ps4.setString(2, auxUsuario);
                    ps4.executeUpdate();
                }
            }
            dispose();

        } catch (SQLException e) {
            System.out.println("Erro ao executar o comando SQL" + e);
        }
        
        campoCpfTorcedor.setEditable(false);
        campoEmailTorcedor.setEditable(false);
        campoNomeTorcedor.setEditable(false);
        campoSenhaTorcedor.setEditable(false);
        campoSobrenomeTorcedor.setEditable(false);
        campoTelefoneTorcedor.setEditable(false);
        
    }//GEN-LAST:event_btnSalvarTorcedorActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnSalvarTorcedor;
    private javax.swing.JButton btnVoltarTorcedor;
    private javax.swing.JTextField campoCpfTorcedor;
    private javax.swing.JTextField campoDoacaoMensal;
    private javax.swing.JTextField campoEmailTorcedor;
    private javax.swing.JTextField campoNomeTorcedor;
    private javax.swing.JTextField campoSenhaTorcedor;
    private javax.swing.JTextField campoSobrenomeTorcedor;
    private javax.swing.JTextField campoTelefoneTorcedor;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    // End of variables declaration//GEN-END:variables
}
