/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import conexao.Persistencia;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author lucas
 */
public class JFrmRealizarDoacao extends javax.swing.JFrame {

    /**
     * Creates new form JFrmRealizarDoacao
     */
    public JFrmRealizarDoacao() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jPopupMenu1 = new javax.swing.JPopupMenu();
        jPopupMenu2 = new javax.swing.JPopupMenu();
        jMenu3 = new javax.swing.JMenu();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        radioDoacao = new javax.swing.JRadioButton();
        radioDoacao2 = new javax.swing.JRadioButton();
        radioDoacao3 = new javax.swing.JRadioButton();
        radioDoacao4 = new javax.swing.JRadioButton();
        caixaMetodoPagamento = new javax.swing.JComboBox();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();

        jMenu3.setText("jMenu3");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Dialog", 3, 36)); // NOI18N
        jLabel1.setText("DOAÇÃO");

        jLabel2.setText("SELECIONE A OPÇÃO:");

        buttonGroup1.add(radioDoacao);
        radioDoacao.setText("R$:19,90");
        radioDoacao.setActionCommand("1");
        radioDoacao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioDoacaoActionPerformed(evt);
            }
        });

        buttonGroup1.add(radioDoacao2);
        radioDoacao2.setText("R$:49,99");
        radioDoacao2.setActionCommand("2");

        buttonGroup1.add(radioDoacao3);
        radioDoacao3.setText("R$:89,99");
        radioDoacao3.setActionCommand("");
        radioDoacao3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioDoacao3ActionPerformed(evt);
            }
        });

        buttonGroup1.add(radioDoacao4);
        radioDoacao4.setText("R$:109,99");
        radioDoacao4.setActionCommand("");

        caixaMetodoPagamento.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "BOLETO BANCARIO", "CARTAO DE CREDITO" }));

        jLabel3.setText("INFORME O METODO DE PAGAMENTO:");

        jButton1.setText("CONFIRMAR DOAÇÃO");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("VOLTAR");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(106, 106, 106)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(radioDoacao)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(radioDoacao2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(radioDoacao3))
                                    .addComponent(jButton1))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jButton2)
                                    .addComponent(radioDoacao4)))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(caixaMetodoPagamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel3)))
                .addContainerGap(44, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(radioDoacao)
                    .addComponent(radioDoacao2)
                    .addComponent(radioDoacao3)
                    .addComponent(radioDoacao4))
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(caixaMetodoPagamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void radioDoacaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioDoacaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_radioDoacaoActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        PreparedStatement ps = null;
        String auxUsuario = JFrmTelaLogin.pegaTelaCadastroJogador();
        try {
            ps = Persistencia.conexao().prepareStatement("Insert into doacao (metodo_pag,nomeUsuario,opcao_pag) values (?,?,?)");
            ps.setObject(1, caixaMetodoPagamento.getSelectedItem());
            ps.setString(2, auxUsuario);
            if (radioDoacao.isSelected()) {
                ps.setString(3, radioDoacao.getText());
            }
            if (radioDoacao2.isSelected()) {
                ps.setString(3, radioDoacao2.getText());
            }
            if (radioDoacao3.isSelected()) {
                ps.setString(3, radioDoacao3.getText());
            }
            if (radioDoacao4.isSelected()) {
                ps.setString(3, radioDoacao4.getText());
            }

            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Erro ao executar comando SQL" + e);
        }
        dispose();
        JOptionPane.showMessageDialog(this, "Doação Realizada com SUCESSO", "SISTEMA", 2);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void radioDoacao3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioDoacao3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_radioDoacao3ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JComboBox caixaMetodoPagamento;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JPopupMenu jPopupMenu2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JRadioButton radioDoacao;
    private javax.swing.JRadioButton radioDoacao2;
    private javax.swing.JRadioButton radioDoacao3;
    private javax.swing.JRadioButton radioDoacao4;
    // End of variables declaration//GEN-END:variables
}
