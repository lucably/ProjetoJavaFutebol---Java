/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;


public class JFrmTelaAdmin extends javax.swing.JFrame {
    JFrmCadastroJogador tela_cadastroJogador;
    JFrmCadastroComissaoTecnica tela_comissaoTecnica;
    JFrmCadastroAdmin tela_admin;
    JFrmCadastroEstrela tela_estrela;
    JFrmDeleteJogador tela_delJogador;
    JFrmDeleteComissao tela_delComissao;
    JFrmDeleteAdmin tela_delAdmin;
    JFrmDeleteEstrela tela_delEstrela;
    JFrmCadastrarCampeonato tela_campeonato;
    JFrmCadastrarPartida tela_partida;
    
    public JFrmTelaAdmin() {
        tela_cadastroJogador = new JFrmCadastroJogador();
        tela_comissaoTecnica = new JFrmCadastroComissaoTecnica();
        tela_admin = new JFrmCadastroAdmin();
        tela_estrela = new JFrmCadastroEstrela();
        tela_delJogador = new JFrmDeleteJogador();
        tela_delComissao = new JFrmDeleteComissao();
        tela_delAdmin = new JFrmDeleteAdmin();
        tela_delEstrela = new JFrmDeleteEstrela();
        tela_campeonato = new JFrmCadastrarCampeonato();
        tela_partida = new JFrmCadastrarPartida();
        initComponents();
        this.setLocationRelativeTo(null);
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton3 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        btnAdminCadastraTorcedor = new javax.swing.JButton();
        btnAdminCadastraComissao = new javax.swing.JButton();
        btnAdminCadastraJogador = new javax.swing.JButton();
        btnAdminCadastraAdmin = new javax.swing.JButton();
        btnAdminLogout = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        btnAdminCadastraAdmin1 = new javax.swing.JButton();
        btnAdminCadastraAdmin2 = new javax.swing.JButton();
        btnAdminCadastraAdmin3 = new javax.swing.JButton();
        btnAdminCadastraAdmin4 = new javax.swing.JButton();

        jButton3.setText("jButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Dialog", 3, 36)); // NOI18N
        jLabel1.setText("TELA ADMINISTRADOR");

        btnAdminCadastraTorcedor.setText("CADASTRAR ESTRELA");
        btnAdminCadastraTorcedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdminCadastraTorcedorActionPerformed(evt);
            }
        });

        btnAdminCadastraComissao.setText("CADASTRAR COMISSAO");
        btnAdminCadastraComissao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdminCadastraComissaoActionPerformed(evt);
            }
        });

        btnAdminCadastraJogador.setText("CADASTRAR JOGADOR");
        btnAdminCadastraJogador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdminCadastraJogadorActionPerformed(evt);
            }
        });

        btnAdminCadastraAdmin.setText("CADASTAR ADMIN");
        btnAdminCadastraAdmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdminCadastraAdminActionPerformed(evt);
            }
        });

        btnAdminLogout.setText("DESLOGAR");
        btnAdminLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdminLogoutActionPerformed(evt);
            }
        });

        jButton1.setText("DEL COMISSAO");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("DEL ESTRELA");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton4.setText("DEL JOGADOR");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setText("DEL ADMIN");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        btnAdminCadastraAdmin1.setText("CADASTAR CAMPEONATO");
        btnAdminCadastraAdmin1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdminCadastraAdmin1ActionPerformed(evt);
            }
        });

        btnAdminCadastraAdmin2.setText("DEL CAMPEONATO");
        btnAdminCadastraAdmin2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdminCadastraAdmin2ActionPerformed(evt);
            }
        });

        btnAdminCadastraAdmin3.setText("CADASTAR PARTIDA");
        btnAdminCadastraAdmin3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdminCadastraAdmin3ActionPerformed(evt);
            }
        });

        btnAdminCadastraAdmin4.setText("DEL PARTIDA");
        btnAdminCadastraAdmin4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdminCadastraAdmin4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(41, 41, 41))
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnAdminLogout, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(btnAdminCadastraJogador, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnAdminCadastraAdmin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnAdminCadastraTorcedor, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnAdminCadastraAdmin1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnAdminCadastraAdmin3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnAdminCadastraComissao, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 181, Short.MAX_VALUE)
                            .addComponent(jButton5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 181, Short.MAX_VALUE)
                            .addComponent(jButton2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnAdminCadastraAdmin2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnAdminCadastraAdmin4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(22, 22, 22))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel1)
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAdminCadastraTorcedor, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAdminCadastraComissao, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAdminCadastraJogador, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAdminCadastraAdmin, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAdminCadastraAdmin1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAdminCadastraAdmin2, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 16, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAdminCadastraAdmin4, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAdminCadastraAdmin3, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(btnAdminLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAdminLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdminLogoutActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btnAdminLogoutActionPerformed

    private void btnAdminCadastraJogadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdminCadastraJogadorActionPerformed
        tela_cadastroJogador.setVisible(true);
    }//GEN-LAST:event_btnAdminCadastraJogadorActionPerformed

    private void btnAdminCadastraComissaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdminCadastraComissaoActionPerformed
        tela_comissaoTecnica.setVisible(true);
    }//GEN-LAST:event_btnAdminCadastraComissaoActionPerformed

    private void btnAdminCadastraAdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdminCadastraAdminActionPerformed
        tela_admin.setVisible(true);
    }//GEN-LAST:event_btnAdminCadastraAdminActionPerformed

    private void btnAdminCadastraTorcedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdminCadastraTorcedorActionPerformed
        tela_estrela.setVisible(true);
    }//GEN-LAST:event_btnAdminCadastraTorcedorActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        tela_delJogador.setVisible(true);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        tela_delComissao.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        tela_delAdmin.setVisible(true);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        tela_delEstrela.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void btnAdminCadastraAdmin1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdminCadastraAdmin1ActionPerformed
        tela_campeonato.setVisible(true);
    }//GEN-LAST:event_btnAdminCadastraAdmin1ActionPerformed

    private void btnAdminCadastraAdmin2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdminCadastraAdmin2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnAdminCadastraAdmin2ActionPerformed

    private void btnAdminCadastraAdmin3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdminCadastraAdmin3ActionPerformed
        tela_partida.setVisible(true);
    }//GEN-LAST:event_btnAdminCadastraAdmin3ActionPerformed

    private void btnAdminCadastraAdmin4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdminCadastraAdmin4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnAdminCadastraAdmin4ActionPerformed

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdminCadastraAdmin;
    private javax.swing.JButton btnAdminCadastraAdmin1;
    private javax.swing.JButton btnAdminCadastraAdmin2;
    private javax.swing.JButton btnAdminCadastraAdmin3;
    private javax.swing.JButton btnAdminCadastraAdmin4;
    private javax.swing.JButton btnAdminCadastraComissao;
    private javax.swing.JButton btnAdminCadastraJogador;
    private javax.swing.JButton btnAdminCadastraTorcedor;
    private javax.swing.JButton btnAdminLogout;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
