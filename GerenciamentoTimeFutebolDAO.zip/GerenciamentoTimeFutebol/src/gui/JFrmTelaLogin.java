/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import conexao.Persistencia;
import java.awt.event.KeyEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author lucas
 */
public class JFrmTelaLogin extends javax.swing.JFrame {

    static String pegaUsuario;
    JFrmCadastroTime tela_cadastroTime;
    JFrmCadastroTorcedor tela_cadastroTorcedor;
    JFrmPerfilJogador tela_perfilJogador;
    JFrmTelaAdmin tela_telaAdmin;
    JFrmTelaPrincipalJogador tela_principalJogador;
    JFrmTelaPrincipalTorcedor tela_principalTorcedor;
    JFrmTelaPrincipalComissaoTecnica tela_principalComissao;

    public JFrmTelaLogin() {
        initComponents();
        campoSenha.setText("");
        tela_cadastroTime = new JFrmCadastroTime();
        tela_cadastroTorcedor = new JFrmCadastroTorcedor();
        tela_perfilJogador = new JFrmPerfilJogador();
        tela_telaAdmin = new JFrmTelaAdmin();
        this.setLocationRelativeTo(null);
    }

    static public String pegaTelaCadastroJogador() {
        return pegaUsuario;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jTextField1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        btnCadastroTime = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        campoUsuario = new javax.swing.JTextField();
        btnSair = new javax.swing.JButton();
        btnLogar = new javax.swing.JButton();
        campoSenha = new javax.swing.JPasswordField();
        jButton1 = new javax.swing.JButton();

        jTextField1.setText("jTextField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setBackground(new java.awt.Color(255, 0, 0));
        jLabel1.setFont(new java.awt.Font("Fira Code", 3, 36)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("LOGIN");
        jLabel1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        btnCadastroTime.setText("CADASTRAR");
        btnCadastroTime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastroTimeActionPerformed(evt);
            }
        });

        jLabel3.setBackground(new java.awt.Color(255, 102, 0));
        jLabel3.setText("USUARIO:");

        jLabel4.setText("SENHA:");

        campoUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoUsuarioActionPerformed(evt);
            }
        });

        btnSair.setText("SAIR");
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        btnLogar.setText("LOGAR");
        btnLogar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogarActionPerformed(evt);
            }
        });

        campoSenha.setText("jPasswordField1");
        campoSenha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoSenhaActionPerformed(evt);
            }
        });

        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(campoSenha, javax.swing.GroupLayout.DEFAULT_SIZE, 222, Short.MAX_VALUE)
                    .addComponent(campoUsuario))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnCadastroTime, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 130, Short.MAX_VALUE)
                        .addComponent(btnSair, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(114, 114, 114)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(136, 136, 136)
                                .addComponent(btnLogar, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 61, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(campoUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel4)
                        .addComponent(campoSenha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(btnLogar)
                .addGap(43, 43, 43)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCadastroTime)
                    .addComponent(btnSair))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void campoUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoUsuarioActionPerformed

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btnSairActionPerformed

    private void campoSenhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoSenhaActionPerformed

    }//GEN-LAST:event_campoSenhaActionPerformed

    private void btnCadastroTimeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastroTimeActionPerformed
        tela_cadastroTorcedor.setVisible(true);
    }//GEN-LAST:event_btnCadastroTimeActionPerformed


    private void btnLogarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogarActionPerformed

        PreparedStatement ps = null;
        ResultSet rs = null;
        int aux = 0;
        try {
            ps = Persistencia.conexao().prepareStatement("Select * from login");
            rs = ps.executeQuery();
            String senha = String.valueOf(campoSenha.getPassword());
            while (rs.next()) {
                if (rs.getString("usuario").equals(campoUsuario.getText()) && rs.getString("senha").equals(senha) && rs.getInt("tipo_usuario") == 0) {
                    this.setVisible(false);
                    aux++;
                    dispose();
                    pegaUsuario = rs.getString("usuario");
                    tela_principalTorcedor = new JFrmTelaPrincipalTorcedor();
                    tela_principalTorcedor.setVisible(true);
                    JOptionPane.showMessageDialog(this, "Bem-Vindo! "+campoUsuario.getText(), "SISTEMA:", 2, null);
                    
                } else if (rs.getString("usuario").equals(campoUsuario.getText()) && rs.getString("senha").equals(senha) && rs.getInt("tipo_usuario") == 1) {
                    this.setVisible(false);
                    aux++;
                    dispose();
                    pegaUsuario = rs.getString("usuario");
                    tela_principalJogador = new JFrmTelaPrincipalJogador();
                    tela_principalJogador.setVisible(true);
                    JOptionPane.showMessageDialog(this, "Bem-Vindo! "+campoUsuario.getText(), "SISTEMA:", 2, null);
                    
                } else if (rs.getString("usuario").equals(campoUsuario.getText()) && rs.getString("senha").equals(senha) && rs.getInt("tipo_usuario") == 2) {
                    this.setVisible(false);
                    aux++;
                    dispose();
                    pegaUsuario = rs.getString("usuario");
                    tela_principalComissao = new JFrmTelaPrincipalComissaoTecnica();
                    tela_principalComissao.setVisible(true);
                    JOptionPane.showMessageDialog(this, "Bem-Vindo! "+campoUsuario.getText(), "SISTEMA:", 2, null);
                    
                } else if (rs.getString("usuario").equals(campoUsuario.getText()) && rs.getString("senha").equals(senha) && rs.getInt("tipo_usuario") == 3) {
                    tela_telaAdmin.setVisible(true);
                    this.setVisible(false);
                    aux++;
                    dispose();
                    pegaUsuario = rs.getString("usuario");
                    JOptionPane.showMessageDialog(this, "Bem-Vindo! "+campoUsuario.getText(), "SISTEMA:", 2, null);
                }
            }
            if (aux == 0) {
                JOptionPane.showMessageDialog(this, "USUARIO e/ou Senha INVALIDOS!", "Erro no Sistema", 0);
                campoUsuario.setText("");
                campoSenha.setText("");
            }
        } catch (SQLException e) {
            System.out.println("Erro ao executar o comando SQL" + e);
        }
        

    }//GEN-LAST:event_btnLogarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String senha = String.valueOf(campoSenha.getPassword());
        campoSenha.toString();
        campoSenha.setText(senha);
    }//GEN-LAST:event_jButton1ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCadastroTime;
    private javax.swing.JButton btnLogar;
    private javax.swing.JButton btnSair;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JPasswordField campoSenha;
    private javax.swing.JTextField campoUsuario;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
