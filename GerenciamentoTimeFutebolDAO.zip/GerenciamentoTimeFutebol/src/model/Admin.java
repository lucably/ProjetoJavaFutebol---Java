/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author lucas
 */
public class Admin {
    private String usuario;
    private int tipoUsuario;
    private String senha;
    
    public Admin() {
        this.usuario = "";
        this.tipoUsuario = 3;
        this.senha = "";
    }

    /**
     * @return the usuario
     */
    public String getUsuario() {
        return usuario;
    }

    /**
     * @param usuario the usuario to set
     */
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    /**
     * @return the tipoUsuario
     */
    public int getTipoUsuario() {
        return tipoUsuario;
    }

    /**
     * @return the nome
     */
    public String getsenha() {
        return senha;
    }

    /**
     * @param nome the nome to set
     */
    public void setsenha(String nome) {
        this.senha = nome;
    }
    
}
