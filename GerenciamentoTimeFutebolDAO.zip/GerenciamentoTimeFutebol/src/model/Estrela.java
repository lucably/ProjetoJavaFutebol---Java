package model;

/**
 *
 * @author lucas
 */
public class Estrela {
    private int anos;
    private int gols;
    private String nome;
    private int qnt_titulos;
    
    public Estrela() {
        this.anos = 0;
        this.gols = 0;
        this.nome = "";
        this.qnt_titulos = 0;
    }

    /**
     * @return the anos
     */
    public int getAnos() {
        return anos;
    }

    /**
     * @param anos the anos to set
     */
    public void setAnos(int anos) {
        this.anos = anos;
    }

    /**
     * @return the gols
     */
    public int getGols() {
        return gols;
    }

    /**
     * @param gols the gols to set
     */
    public void setGols(int gols) {
        this.gols = gols;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the qnt_titulos
     */
    public int getQnt_titulos() {
        return qnt_titulos;
    }

    /**
     * @param qnt_titulos the qnt_titulos to set
     */
    public void setQnt_titulos(int qnt_titulos) {
        this.qnt_titulos = qnt_titulos;
    }
    
    
    
}